/* Optional browser verification. Start app.py --demo --port 8765 first.
   npm install --no-save playwright && npx playwright install chromium
   node source/tests/test_ui.cjs */
const {chromium}=require('playwright');
const assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.KITCHEN_BROWSER||undefined,args:[...JSON.parse(process.env.KITCHEN_BROWSER_ARGS||'[]'),'--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream']});
 const context=await browser.newContext({viewport:{width:1440,height:1100},permissions:['camera','microphone'],acceptDownloads:true});
 const page=await context.newPage(),errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 await page.goto(process.env.KITCHEN_TEST_URL||'http://127.0.0.1:8765');
 if(process.env.KITCHEN_FONT_CSS){await page.addStyleTag({content:require('fs').readFileSync(process.env.KITCHEN_FONT_CSS,'utf8')});await page.evaluate(()=>document.fonts.ready);}
 await page.waitForFunction(()=>document.getElementById('modeBadge').textContent.includes('DEMO'));
 await page.locator('#cameraStart').click();
 await page.waitForFunction(()=>document.getElementById('video').videoWidth>0);
 await page.locator('#capture').click();
 await page.waitForFunction(()=>document.getElementById('ingredients').value.includes('달걀'));
 await page.locator('#reviewIngredients').check();await page.locator('#recommend').click();
 await page.locator('.menu-card').first().waitFor();
 assert.equal(await page.locator('.menu-card').count(),3);
 await page.locator('.menu-card').first().click();
 await page.waitForFunction(()=>document.getElementById('book').textContent.includes('재료와 분량'));
 await page.locator('#next').click();
 assert.ok((await page.locator('#book').innerText()).includes('재료 손질'));
 // Verify real gesture dispatch routing via mocked recognition results, not a fake gesture button.
 let pose='None';
 await page.route('**/api/gesture',route=>route.fulfill({json:{gesture:pose,score:pose==='None'?0:.99}}));
 await page.locator('#gestureToggle').click();
 const gesture=async(name)=>{pose='None';await page.waitForTimeout(650);pose=name;await page.waitForTimeout(1250);pose='None';await page.waitForTimeout(650);};
 await gesture('Thumb_Up');
 assert.ok((await page.locator('#book').innerText()).includes('달걀 볶기'));
 assert.equal(await page.locator('#clock').innerText(),'01:00');
 if(process.env.KITCHEN_SCREENSHOT){await page.screenshot({path:process.env.KITCHEN_SCREENSHOT,fullPage:true});}
 await gesture('Victory');
 assert.equal(await page.locator('#gestureMode').innerText(),'타이머 모드');
 assert.equal(await page.locator('#clock').innerText(),'01:00');
 await gesture('Pointing_Up');
 assert.equal(await page.locator('#clock').innerText(),'02:00');
 await gesture('Open_Palm');
 assert.equal(await page.locator('#clock').innerText(),'01:00');
 await gesture('Thumb_Up');
 assert.ok((await page.locator('#timerState').innerText()).includes('작동 중'));
 await gesture('Thumb_Down');
 assert.ok((await page.locator('#timerState').innerText()).includes('일시정지'));
 await gesture('Closed_Fist');
 assert.equal(await page.locator('#clock').innerText(),'01:00');
 await gesture('ILoveYou');
 assert.ok((await page.locator('#increment').innerText()).includes('5분'));
 await gesture('Victory');
 assert.equal(await page.locator('#gestureMode').innerText(),'책 모드');
 await gesture('Thumb_Down');
 assert.ok((await page.locator('#book').innerText()).includes('재료 손질'));
 await page.locator('#gestureToggle').click();
 // Timer keeps running across page changes and refresh; expiry is only emitted once.
 await page.locator('.timer-manual summary').click();await page.locator('#minutes').fill('0');await page.locator('#seconds').fill('8');await page.locator('#setTimer').click();
 await page.locator('#startTimer').click();await page.locator('#next').click();await page.waitForTimeout(1200);
 await page.reload();await page.waitForFunction(()=>document.getElementById('timerState').textContent.includes('작동 중'));
 await page.waitForFunction(()=>document.getElementById('timerState').textContent.includes('시간이 되었습니다'),null,{timeout:12000});
 const download=page.waitForEvent('download');await page.locator('#exportBook').click();assert.equal((await download).suggestedFilename(),'recipe-book.json');
 if(process.env.KITCHEN_FONT_CSS){await page.addStyleTag({content:require('fs').readFileSync(process.env.KITCHEN_FONT_CSS,'utf8')});await page.evaluate(()=>document.fonts.ready);}
 await page.locator('#focusMode').click();
 if(process.env.KITCHEN_SCREENSHOT)await page.screenshot({path:process.env.KITCHEN_SCREENSHOT.replace('.png','-focus.png'),fullPage:true});
 await page.setViewportSize({width:390,height:844});
 if(process.env.KITCHEN_SCREENSHOT)await page.screenshot({path:process.env.KITCHEN_SCREENSHOT.replace('.png','-mobile.png'),fullPage:true});
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
 assert.deepEqual(errors,[]);
 console.log('PASS: webcam capture, menus, recipe, all seven gesture routes, timer continuity/expiry, download, mobile layout; recognition mocked.');
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1);});
